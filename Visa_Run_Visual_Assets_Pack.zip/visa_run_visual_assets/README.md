# Visa Run Visual Assets Pack

Prototype visual assets for **Visa Run: The Border Is Closing**.

## Included

- `role_cards/`: printable role cards, plus a role card back
- `document_cards/`: printable document cards, plus a document card back
- `crisis_cards/`: printable crisis cards, plus a crisis card back
- `status_tokens/`: square status token visuals
- `contact_sheets/`: overview images for quick review

## Format

- PNG files
- Card ratio: 750 x 1050 px
- Status token ratio: 600 x 600 px

## Art direction

Clean prototype style:
- dark navy frame
- teal for Nomads / valid systems
- red for danger, Scammers and Heat
- gold for money, documents and independent incentives
- simple original line-art icons

These are prototype visuals, not final production illustrations.
