# Visa Run v0.1 Print-and-Play Kit

This package contains everything needed to run the first controlled playtest of **Visa Run: The Border Is Closing**.

## Recommended playtest

- 9 players
- 1 Fixer
- 45 to 75 minutes
- 5 in-game days

## Print order

1. Print the player quick rules once or twice.
2. Print the Fixer Guide for the Fixer only.
3. Print role cards, document cards and crisis cards.
4. Print status tokens and cut them out.
5. Print Dossier mats: one per player.
6. Print Heat Track and Border Clock.
7. Print the Setup Sheet and Final Border Check Sheet for the Fixer.

## Print settings

- Paper: A4
- Scaling: Actual size / 100%
- Suggested paper: 200-300 gsm for cards, normal paper for reference sheets
- Cut along the crop marks

## First test goal

Do not test perfect balance yet. Test whether players naturally lie, negotiate, accuse, protect their Dossiers and want to play again.
