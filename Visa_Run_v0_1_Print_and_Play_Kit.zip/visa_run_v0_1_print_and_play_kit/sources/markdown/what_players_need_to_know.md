# What Players Need to Know

You are trying to leave before the border closes.

Most players are **Nomads**.

Some players are **Scammers**.

Some players have **personal objectives**.

Your **Dossier** may contain fake, expired or suspicious documents.

You may not know your own documents are bad.

Talk privately, share info, lie if needed.

The group votes each day.

**Heat** makes the border stricter.

Deported players still talk, but do not count as legal exits.

At the end, The Fixer checks who can legally leave.
