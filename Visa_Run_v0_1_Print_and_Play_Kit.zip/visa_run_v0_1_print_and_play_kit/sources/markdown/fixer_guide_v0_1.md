# Fixer Guide v0.1

The Fixer runs the game, manages secret information, resolves documents, controls Crisis Cards, tracks Heat, and decides who can legally leave during the Final Border Check.

## Recommended Setup

9 players + 1 Fixer. Use 6 Nomads, 2 Scammers and 1 Independent.

### Roles

Nomads: Embassy Contact, Remote Worker, Paranoid Planner, Overstayer, Backpacker, Local Fixer.

Scammers: Fake Visa Agent, Corrupt Officer.

Independent: Crypto Bro.

## Night Order

1. Corrupt Officer chooses one player to block.
2. Fake Visa Agent adds one fake or suspicious document.
3. Local Fixer may repair one document if using ability.
4. Embassy Contact checks one player and one document type.
5. Paranoid Planner receives tomorrow's crisis hint.
6. Fixer updates notes.

## Daily Flow

Night Phase -> Morning Briefing -> Private Chats -> Public Accusation -> Vote -> Crisis Reveal.

## Final Border Check

With 9 players, Nomads need at least 5 legal exits. If 4 or fewer players can legally leave, Scammers win.
