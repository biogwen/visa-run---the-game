# Visa Run Fixer Console v0.5

Local Pocket-Grimoire-style assistant for **Visa Run: The Border Is Closing**.

## v0.5 changes

The old **Load v0.1 setup** button has been replaced by a real **Load scenario** system.

You can now:

- open a scenario loader panel
- choose a built-in scenario
- load the beginner scenario
- load other built-in scenarios
- import a custom scenario JSON
- download a custom scenario JSON template

## Built-in scenarios

Included in v0.5:

1. **Beginner Visa Run**
   - recommended first game
   - 9 players
   - 5 days
   - simple roles
   - moderate Heat

2. **High Chaos Visa Run**
   - more pressure
   - more document confusion
   - 10 players
   - stronger Scammers

3. **Tax Haven Prototype**
   - advanced/satirical
   - banking, compliance, bad advice, suspicious structures

## Custom scenario JSON

The app can import a scenario JSON with this structure:

```json
{
  "id": "my-custom-scenario",
  "name": "My Custom Scenario",
  "difficulty": "Custom",
  "description": "Short description of the scenario.",
  "legalExitsNeeded": 5,
  "maxHeat": 6,
  "startingHeat": 0,
  "players": [
    {
      "id": 1,
      "name": "Player 1",
      "role": "Embassy Contact",
      "team": "Nomad",
      "status": ["Active"],
      "notes": "Role notes for the Fixer.",
      "history": [],
      "dossier": [
        {
          "visibleName": "Passport",
          "secretTruth": "Valid",
          "visibleToPlayer": true,
          "source": "setup",
          "notes": "",
          "cleared": false
        }
      ]
    }
  ],
  "days": [
    {
      "id": 1,
      "name": "Random Passport Check",
      "type": "Light Crisis",
      "text": "Public text read to players.",
      "fixer": "Secret Fixer instructions."
    }
  ],
  "nightOrder": [
    {
      "role": "Embassy Contact",
      "prompt": "Choose one player and one document type."
    }
  ]
}
```

You can also click **Download scenario template** inside the app.

## Quick test

1. Unzip the file.
2. Open `index.html` in your browser.
3. Click **Load scenario**.
4. Choose **Beginner Visa Run**.
5. Confirm that the game loads.

## Test custom JSON

1. Click **Load scenario**.
2. Click **Download scenario template**.
3. Edit the template.
4. Import it with **Import custom scenario JSON**.

## Test with a local server

From the folder:

```bash
python3 -m http.server 8000
```

Then open:

```text
http://localhost:8000
```
