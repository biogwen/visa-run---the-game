const STORAGE_KEY = "visa_run_fixer_console_v0_5";

const statuses = ["Active", "Flagged", "Audited", "Cleared", "Compromised", "Protected", "Deported", "Under Review", "Blocked Tonight"];
const documentTruths = ["Valid", "Fake", "Expired", "Suspicious", "Missing", "Hidden Complication", "Pending", "Unknown"];
const supportDocs = ["Proof of Funds", "Travel Insurance", "Local Address", "Embassy Letter", "Bank Statement", "Local Contact", "Police Clearance", "Hotel Booking"];
const coreDocs = ["Passport", "Visa Stamp", "Exit Ticket"];

function doc(visibleName, secretTruth = "Valid", visibleToPlayer = true, source = "setup", notes = "") {
  return { visibleName, secretTruth, visibleToPlayer, source, notes, cleared: false };
}

function player(id, name, role, team, notes, dossier) {
  return { id, name, role, team, status: ["Active"], notes, history: [], dossier };
}

function clone(obj) { return JSON.parse(JSON.stringify(obj)); }

const builtInScenarios = [
  {
    id: "beginner-visa-run",
    name: "Beginner Visa Run",
    difficulty: "Beginner",
    description: "The recommended first game. 9 players, simple roles, 5 days, moderate Heat and clear Dossier pressure.",
    legalExitsNeeded: 5,
    maxHeat: 6,
    startingHeat: 0,
    players: [
      player(1, "Alice", "Embassy Contact", "Nomad", "Each night, choose one player and one document type. Learn Valid / Invalid / Suspicious / Unknown.", [
        doc("Passport", "Valid", true, "setup"), doc("Visa Stamp", "Valid", true, "setup"), doc("Exit Ticket", "Suspicious", true, "setup"), doc("Travel Insurance", "Valid", true, "setup")
      ]),
      player(2, "Ben", "Remote Worker", "Nomad", "Once per game, protect Dossier from sabotage tonight.", [
        doc("Passport", "Valid", true, "setup"), doc("Visa Stamp", "Valid", true, "setup"), doc("Exit Ticket", "Valid", true, "setup"), doc("Remote Work Exposure", "Hidden Complication", false, "setup")
      ]),
      player(3, "Clara", "Paranoid Planner", "Nomad", "Each morning, receive a hint about today’s Crisis before the group acts.", [
        doc("Passport", "Valid", true, "setup"), doc("Visa Stamp", "Expired", true, "setup"), doc("Exit Ticket", "Valid", true, "setup"), doc("Bank Statement", "Valid", true, "setup")
      ]),
      player(4, "Diego", "Overstayer", "Nomad", "If Overstay Risk is publicly exposed, Heat rises by 2.", [
        doc("Passport", "Valid", true, "setup"), doc("Visa Stamp", "Suspicious", true, "setup"), doc("Exit Ticket", "Valid", true, "setup"), doc("Overstay Risk", "Hidden Complication", false, "setup")
      ]),
      player(5, "Emma", "Backpacker", "Nomad", "No night ability. If Active on Day 5, final vote counts double.", [
        doc("Passport", "Valid", true, "setup"), doc("Visa Stamp", "Valid", true, "setup"), doc("Exit Ticket", "Missing", true, "setup"), doc("Travel Insurance", "Valid", true, "setup")
      ]),
      player(6, "Farah", "Local Fixer", "Nomad", "Once per game, repair one document or cancel one Crisis effect.", [
        doc("Passport", "Valid", true, "setup"), doc("Visa Stamp", "Valid", true, "setup"), doc("Exit Ticket", "Valid", true, "setup"), doc("Embassy Letter", "Valid", true, "setup")
      ]),
      player(7, "Hugo", "Fake Visa Agent", "Scammer", "Each night, add one fake or suspicious document to a player’s Dossier.", [
        doc("Passport", "Valid", true, "setup"), doc("Visa Stamp", "Valid", true, "setup"), doc("Exit Ticket", "Valid", true, "setup"), doc("Local Contact", "Valid", true, "setup")
      ]),
      player(8, "Maya", "Corrupt Officer", "Scammer", "Each night, block one player’s ability or official check.", [
        doc("Passport", "Valid", true, "setup"), doc("Visa Stamp", "Valid", true, "setup"), doc("Exit Ticket", "Suspicious", true, "setup"), doc("Proof of Funds", "Valid", true, "setup")
      ]),
      player(9, "Leo", "Crypto Bro", "Independent", "Wins personally if 3 players buy the useless crypto-residency solution.", [
        doc("Passport", "Valid", true, "setup"), doc("Visa Stamp", "Suspicious", true, "setup"), doc("Exit Ticket", "Valid", true, "setup"), doc("Bank Statement", "Valid", true, "setup")
      ])
    ],
    days: [
      { id: 1, name: "Random Passport Check", type: "Light Crisis", text: "Choose two players. Each must reveal whether they have a Passport.", fixer: "Do not reveal validity. A player may show a Passport, but it can still be Fake, Suspicious or Wrong Name." },
      { id: 2, name: "Immigration Website Down", type: "Administrative Crisis", text: "No online validation can happen today. The group may use a private agent, but Heat may rise.", fixer: "If the group uses a private agent, Heat +1. If a Scammer is involved, one document may become Suspicious." },
      { id: 3, name: "Coworking Rumor", type: "Social Crisis", text: "Each player publicly accuses one person. The most accused player becomes Flagged.", fixer: "If tied, either no one is Flagged and Heat +1, or all tied players become Audited. Choose before the game starts." },
      { id: 4, name: "Remote Work Crackdown", type: "Heat Crisis", text: "Remote Workers, Freelancers and suspicious employment files are at risk if audited today.", fixer: "If a player with Remote Work Exposure is audited today, they become Flagged. Do not reveal the complication unless an audit exposes it." },
      { id: 5, name: "Final Border Window", type: "Final Crisis", text: "The group may Deport one player or Clear one player before the Final Border Check.", fixer: "After this choice, run the Final Border Check. Deported players do not count as legal exits." }
    ],
    nightOrder: [
      { role: "Corrupt Officer", prompt: "Choose one player to block tonight. If that player expects information, give 'No result'." },
      { role: "Fake Visa Agent", prompt: "Choose one player to receive a fake or suspicious document. The target does not automatically know it is fake." },
      { role: "Local Fixer", prompt: "Ask if they use their once-per-game ability. Repair a document or cancel a Crisis effect." },
      { role: "Embassy Contact", prompt: "Choose one player and one document type. Give Valid / Invalid / Suspicious / Unknown." },
      { role: "Paranoid Planner", prompt: "Give a useful but incomplete hint about tomorrow's Crisis." }
    ]
  },
  {
    id: "high-chaos-visa-run",
    name: "High Chaos Visa Run",
    difficulty: "Intermediate",
    description: "More pressure, stronger document confusion, higher starting Heat and more severe crises.",
    legalExitsNeeded: 5,
    maxHeat: 6,
    startingHeat: 1,
    players: [
      player(1, "Player 1", "Embassy Contact", "Nomad", "Information role.", [doc("Passport", "Valid"), doc("Visa Stamp", "Valid"), doc("Exit Ticket", "Suspicious"), doc("Travel Insurance", "Valid")]),
      player(2, "Player 2", "Border Runner", "Nomad", "Once per game, move a document secretly.", [doc("Passport", "Valid"), doc("Visa Stamp", "Suspicious"), doc("Exit Ticket", "Valid"), doc("Local Address", "Suspicious")]),
      player(3, "Player 3", "Paranoid Planner", "Nomad", "Receives crisis hints.", [doc("Passport", "Valid"), doc("Visa Stamp", "Expired"), doc("Exit Ticket", "Valid"), doc("Bank Statement", "Valid")]),
      player(4, "Player 4", "Overstayer", "Nomad", "Dangerous hidden complication.", [doc("Passport", "Valid"), doc("Visa Stamp", "Suspicious"), doc("Exit Ticket", "Valid"), doc("Overstay Risk", "Hidden Complication", false)]),
      player(5, "Player 5", "Local Fixer", "Nomad", "Can repair one document or cancel one crisis.", [doc("Passport", "Valid"), doc("Visa Stamp", "Valid"), doc("Exit Ticket", "Suspicious"), doc("Embassy Letter", "Valid")]),
      player(6, "Player 6", "Backpacker", "Nomad", "Final vote counts double if Active.", [doc("Passport", "Valid"), doc("Visa Stamp", "Valid"), doc("Exit Ticket", "Missing"), doc("Travel Insurance", "Valid")]),
      player(7, "Player 7", "Fake Visa Agent", "Scammer", "Adds fake/suspicious documents.", [doc("Passport", "Valid"), doc("Visa Stamp", "Valid"), doc("Exit Ticket", "Valid"), doc("Local Contact", "Valid")]),
      player(8, "Player 8", "Corrupt Officer", "Scammer", "Blocks checks.", [doc("Passport", "Valid"), doc("Visa Stamp", "Valid"), doc("Exit Ticket", "Suspicious"), doc("Proof of Funds", "Valid")]),
      player(9, "Player 9", "Passport Thief", "Scammer", "Steals or swaps documents.", [doc("Passport", "Valid"), doc("Visa Stamp", "Valid"), doc("Exit Ticket", "Valid"), doc("Bank Statement", "Suspicious")]),
      player(10, "Player 10", "YouTube Expert", "Independent", "Wins if bad advice is followed twice.", [doc("Passport", "Valid"), doc("Visa Stamp", "Suspicious"), doc("Exit Ticket", "Valid"), doc("Bank Statement", "Suspicious")])
    ],
    days: [
      { id: 1, name: "Embassy Closed", type: "Administrative Crisis", text: "The embassy is closed. The group must use a private contact or lose today’s validation.", fixer: "Private contact: Heat +1. If Scammer-linked, one Dossier becomes Compromised." },
      { id: 2, name: "Flight Cancelled", type: "Travel Crisis", text: "All Exit Tickets become Suspicious unless already Cleared.", fixer: "Mark uncleared Exit Tickets as Suspicious." },
      { id: 3, name: "Fake Agent Arrested", type: "Scammer Crisis", text: "A fake agent was arrested. One document in play is fake.", fixer: "Choose or confirm one fake document. Do not reveal whose unless audited." },
      { id: 4, name: "Tourist Area Raid", type: "Heat Crisis", text: "Flagged players must pass a document check or Heat rises.", fixer: "Each Flagged player needs one valid core document checked. Failures increase Heat." },
      { id: 5, name: "Final Border Window", type: "Final Crisis", text: "The group may Deport one player or Clear one player before the Final Border Check.", fixer: "Resolve one final vote, then run Final Border Check." }
    ],
    nightOrder: [
      { role: "Corrupt Officer", prompt: "Choose one player to block tonight." },
      { role: "Passport Thief", prompt: "Choose a document to steal or swap." },
      { role: "Fake Visa Agent", prompt: "Add one fake or suspicious document." },
      { role: "Local Fixer", prompt: "May repair one document or cancel one crisis." },
      { role: "Embassy Contact", prompt: "Check one player and one document type." },
      { role: "Paranoid Planner", prompt: "Give a hint about tomorrow’s crisis." }
    ]
  },
  {
    id: "tax-haven-prototype",
    name: "Tax Haven Prototype",
    difficulty: "Advanced / Satirical",
    description: "A niche entrepreneur/expat scenario about banks, compliance, bad advice and suspicious tax structures.",
    legalExitsNeeded: 5,
    maxHeat: 6,
    startingHeat: 1,
    players: [
      player(1, "Player 1", "Accountant", "Nomad", "Checks one financial document each night.", [doc("Passport", "Valid"), doc("Visa Stamp", "Valid"), doc("Exit Ticket", "Valid"), doc("Tax Certificate", "Suspicious")]),
      player(2, "Player 2", "Lawyer", "Nomad", "Can distinguish risky vs illegal once per game.", [doc("Passport", "Valid"), doc("Visa Stamp", "Valid"), doc("Exit Ticket", "Valid"), doc("Bank Statement", "Valid")]),
      player(3, "Player 3", "Flag Theory Nerd", "Nomad", "Receives lots of partial context.", [doc("Passport", "Valid"), doc("Visa Stamp", "Suspicious"), doc("Exit Ticket", "Valid"), doc("Company Registry", "Pending")]),
      player(4, "Player 4", "Remote Founder", "Nomad", "Needs compliance support.", [doc("Passport", "Valid"), doc("Visa Stamp", "Valid"), doc("Exit Ticket", "Valid"), doc("Bank Freeze Risk", "Hidden Complication", false)]),
      player(5, "Player 5", "Local Fixer", "Nomad", "Can repair or clear one document.", [doc("Passport", "Valid"), doc("Visa Stamp", "Valid"), doc("Exit Ticket", "Valid"), doc("Embassy Letter", "Valid")]),
      player(6, "Player 6", "Bad Advisor", "Scammer", "Corrupts information and pushes unsafe structures.", [doc("Passport", "Valid"), doc("Visa Stamp", "Valid"), doc("Exit Ticket", "Valid"), doc("Local Contact", "Valid")]),
      player(7, "Player 7", "Offshore Scammer", "Scammer", "Adds fake compliance documents.", [doc("Passport", "Valid"), doc("Visa Stamp", "Valid"), doc("Exit Ticket", "Valid"), doc("Proof of Funds", "Valid")]),
      player(8, "Player 8", "Bank Compliance Officer", "Scammer", "Blocks banking checks.", [doc("Passport", "Valid"), doc("Visa Stamp", "Suspicious"), doc("Exit Ticket", "Valid"), doc("Bank Statement", "Valid")]),
      player(9, "Player 9", "YouTube Expert", "Independent", "Wins if two pieces of bad tax advice are followed.", [doc("Passport", "Valid"), doc("Visa Stamp", "Suspicious"), doc("Exit Ticket", "Valid"), doc("Crypto Proof of Funds", "Suspicious")])
    ],
    days: [
      { id: 1, name: "Bank KYC Request", type: "Compliance Crisis", text: "The bank requests additional documents. Choose one player to provide support.", fixer: "If their support document is fake/suspicious, Heat +1." },
      { id: 2, name: "Tax Residency Question", type: "Legal Crisis", text: "The group must decide who gives the official explanation.", fixer: "If a Scammer is chosen, mark one document Suspicious." },
      { id: 3, name: "Account Freeze Rumor", type: "Banking Crisis", text: "One player’s banking documents are now Under Review.", fixer: "Choose a player with bank-related documents or randomize." },
      { id: 4, name: "Bad Advice Goes Viral", type: "Social Crisis", text: "The group may follow a shortcut or take the slow legal route.", fixer: "Shortcut: Heat +1 and one player gets a fake support document." },
      { id: 5, name: "Final Compliance Check", type: "Final Crisis", text: "Clear one player or Deport one player before the Final Border Check.", fixer: "Resolve final choice, then check exits." }
    ],
    nightOrder: [
      { role: "Bank Compliance Officer", prompt: "Choose one player to block tonight." },
      { role: "Offshore Scammer", prompt: "Add one fake or suspicious compliance document." },
      { role: "Bad Advisor", prompt: "Corrupt one information result." },
      { role: "Accountant", prompt: "Check one financial document." },
      { role: "Lawyer", prompt: "May ask whether one strategy is safe, risky or illegal." },
      { role: "Local Fixer", prompt: "May repair or clear one document." }
    ]
  }
];

const blankState = {
  scenarioName: "Custom Scenario",
  scenarioId: "custom",
  legalExitsNeeded: 1,
  maxHeat: 6,
  startingHeat: 0,
  heat: 0,
  currentDayId: 1,
  selectedId: null,
  nightStep: 0,
  nightBoxHidden: false,
  log: ["Blank game created."],
  snapshots: [],
  players: [],
  days: [{ id: 1, name: "Day 1 Crisis", type: "Custom Crisis", text: "Write the public crisis text here.", fixer: "Write the Fixer instructions here." }],
  nightOrder: []
};

let state = loadState();

function scenarioToState(scenario) {
  const next = {
    scenarioName: scenario.name || "Custom Scenario",
    scenarioId: scenario.id || "custom",
    legalExitsNeeded: Number(scenario.legalExitsNeeded || Math.max(1, Math.ceil((scenario.players || []).length / 2))),
    maxHeat: Number(scenario.maxHeat || 6),
    startingHeat: Number(scenario.startingHeat || 0),
    heat: Number(scenario.startingHeat || 0),
    currentDayId: (scenario.days && scenario.days[0] ? scenario.days[0].id : 1),
    selectedId: (scenario.players && scenario.players[0] ? scenario.players[0].id : null),
    nightStep: 0,
    nightBoxHidden: false,
    log: [`Scenario loaded: ${scenario.name || "Custom Scenario"}.`],
    snapshots: [],
    players: clone(scenario.players || []),
    days: clone(scenario.days || []),
    nightOrder: clone(scenario.nightOrder || [])
  };
  return migrateState(next);
}

function loadState() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? migrateState(JSON.parse(saved)) : clone(blankState);
  } catch {
    return clone(blankState);
  }
}

function migrateState(s) {
  s.scenarioName ??= "Custom Scenario";
  s.scenarioId ??= "custom";
  s.legalExitsNeeded ??= Math.max(1, Math.ceil((s.players?.length || 1) / 2));
  s.maxHeat ??= 6;
  s.startingHeat ??= 0;
  s.heat ??= s.startingHeat;
  s.currentDayId ??= 1;
  s.nightStep ??= 0;
  s.nightBoxHidden ??= false;
  s.log ??= [];
  s.snapshots ??= [];
  s.days ??= s.crises ?? clone(blankState.days);
  s.nightOrder ??= [];
  s.players ??= [];
  s.players.forEach((p, index) => {
    p.id ??= index + 1;
    p.name ??= `Player ${p.id}`;
    p.role ??= "Unknown Role";
    p.team ??= "Unknown";
    p.notes ??= "";
    p.history ??= [];
    p.status ??= ["Active"];
    p.dossier ??= [];
    p.dossier = p.dossier.map(d => ({
      visibleName: d.visibleName ?? d.name ?? "Document",
      secretTruth: d.secretTruth ?? d.state ?? "Valid",
      visibleToPlayer: d.visibleToPlayer ?? d.visible ?? true,
      source: d.source ?? "legacy",
      notes: d.notes ?? "",
      cleared: d.cleared ?? false
    }));
  });
  return s;
}

function snapshot() {
  const copy = clone(state);
  copy.snapshots = [];
  state.snapshots ??= [];
  state.snapshots.unshift(copy);
  state.snapshots = state.snapshots.slice(0, 15);
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function addLog(message, rerender = true) {
  const stamp = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  state.log.unshift(`[${stamp}] ${message}`);
  saveState();
  if (rerender) render();
}

function addPlayerHistory(p, message) {
  const day = currentDay()?.id ?? "-";
  const stamp = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  p.history.unshift(`[Day ${day}, ${stamp}] ${message}`);
}

function selectedPlayer() {
  if (state.selectedId === null) return null;
  return state.players.find(p => p.id === state.selectedId) || null;
}

function currentDay() {
  return state.days.find(d => d.id === state.currentDayId) || state.days[0] || null;
}

function heatEffect(heat) {
  if (heat <= 0) return "Heat 0: Border checks are light.";
  if (heat === 1) return "Heat 1: Basic paperwork is checked.";
  if (heat === 2) return "Heat 2: Players need 1 Supporting Document.";
  if (heat === 3) return "Heat 3: Suspicious documents become risky.";
  if (heat === 4) return "Heat 4: Strict checks. 2 Supporting Documents or 1 Cleared key document.";
  if (heat === 5) return "Heat 5: One random document check before exit.";
  return "Heat 6: Border Lockdown. Scammers win unless a special effect prevents it.";
}

function hasGoodDoc(player, docName) {
  return player.dossier.some(d => d.visibleName === docName && ["Valid", "Suspicious"].includes(d.secretTruth));
}

function supportCount(player) {
  return player.dossier.filter(d => supportDocs.includes(d.visibleName) && ["Valid", "Suspicious"].includes(d.secretTruth)).length;
}

function playerWarnings(player) {
  const warnings = [];
  if (!hasGoodDoc(player, "Passport")) warnings.push("No valid Passport");
  if (!hasGoodDoc(player, "Visa Stamp")) warnings.push("No valid Visa Stamp");
  if (!hasGoodDoc(player, "Exit Ticket")) warnings.push("No valid Exit Ticket");
  if (state.heat >= 4 && player.dossier.some(d => coreDocs.includes(d.visibleName) && d.secretTruth === "Suspicious" && !d.cleared && !player.status.includes("Cleared"))) warnings.push("Suspicious core at Heat 4+");
  if (player.status.includes("Deported")) warnings.push("Deported");
  return warnings;
}

function likelyExit(player) {
  if (player.status.includes("Deported")) return false;
  if (!hasGoodDoc(player, "Passport")) return false;
  if (!hasGoodDoc(player, "Visa Stamp")) return false;
  if (!hasGoodDoc(player, "Exit Ticket")) return false;
  const support = supportCount(player);
  if (state.heat >= 2 && support < 1) return false;
  if (state.heat >= 4 && support < 2 && !player.status.includes("Cleared") && !player.dossier.some(d => d.cleared)) return false;
  const hasUnclearedSuspiciousCore = player.dossier.some(d => coreDocs.includes(d.visibleName) && d.secretTruth === "Suspicious" && !d.cleared);
  if (state.heat >= 4 && hasUnclearedSuspiciousCore && !player.status.includes("Cleared")) return false;
  return true;
}

function teamClass(team) {
  return (team || "unknown").toLowerCase();
}

function renderScenarioPanel() {
  const grid = document.getElementById("scenarioGrid");
  grid.innerHTML = builtInScenarios.map(s => `
    <button class="scenario-card" data-scenario-id="${escapeAttr(s.id)}">
      <h3>${escapeHtml(s.name)}</h3>
      <span class="badge">${escapeHtml(s.difficulty)}</span>
      <p>${escapeHtml(s.description)}</p>
      <small>${s.players.length} players · ${s.days.length} days · ${s.nightOrder.length} night steps</small>
    </button>
  `).join("");
  grid.querySelectorAll("[data-scenario-id]").forEach(btn => {
    btn.onclick = () => {
      const scenario = builtInScenarios.find(s => s.id === btn.dataset.scenarioId);
      if (!scenario) return;
      if (!confirm(`Load scenario "${scenario.name}"? The current game will be replaced.`)) return;
      snapshot();
      state = scenarioToState(scenario);
      document.getElementById("scenarioPanel").classList.add("hidden");
      addLog(`Scenario loaded: ${scenario.name}.`);
    };
  });
}

function renderHeat() {
  document.getElementById("heatValue").textContent = state.heat;
  const boxes = document.getElementById("heatBoxes");
  boxes.innerHTML = "";
  const max = Math.max(6, Number(state.maxHeat || 6));
  for (let i = 0; i <= max; i++) {
    const div = document.createElement("div");
    div.className = "heat-box" + (i <= state.heat ? " hot" : "");
    div.innerHTML = `<div class="heat-number">${i}</div><small>Heat</small>`;
    boxes.appendChild(div);
  }
  document.getElementById("heatEffect").textContent = heatEffect(state.heat);
}

function renderConfig() {
  document.getElementById("scenarioNameBadge").textContent = state.scenarioName || "Custom";
  document.getElementById("scenarioNameInput").value = state.scenarioName || "";
  document.getElementById("legalExitsNeededInput").value = state.legalExitsNeeded || 1;
  document.getElementById("maxHeatInput").value = state.maxHeat || 6;
  document.getElementById("startingHeatInput").value = state.startingHeat || 0;
}

function renderWarnings() {
  const box = document.getElementById("warningsBox");
  const warnings = [];
  if (state.heat >= state.maxHeat) warnings.push(`Heat reached ${state.heat}. Border Lockdown threshold is ${state.maxHeat}.`);
  state.players.forEach(p => {
    if (!p.dossier.some(d => d.visibleName === "Passport")) warnings.push(`${p.name} has no Passport card.`);
    if (state.heat >= 4 && p.dossier.some(d => d.secretTruth === "Suspicious" && !d.cleared)) warnings.push(`${p.name} has Suspicious document(s) at Heat 4+.`);
  });
  box.innerHTML = warnings.map(w => `<div class="warning-item">${escapeHtml(w)}</div>`).join("");
}

function renderPlayers() {
  const grid = document.getElementById("playerGrid");
  const q = document.getElementById("searchInput").value.toLowerCase();
  grid.innerHTML = "";
  state.players
    .filter(p => p.name.toLowerCase().includes(q) || p.role.toLowerCase().includes(q))
    .forEach(p => {
      const card = document.createElement("button");
      card.className = "player-card" + (p.id === state.selectedId ? " selected" : "");
      card.innerHTML = `
        <div class="player-card-header">
          <h3>${escapeHtml(p.name)}</h3>
          <span>${p.status.includes("Deported") ? "✖" : "✓"}</span>
        </div>
        <span class="badge ${teamClass(p.team)}">${escapeHtml(p.team)}</span>
        ${p.status.slice(0, 3).map(s => `<span class="badge">${escapeHtml(s)}</span>`).join("")}
        <p class="role-line">${escapeHtml(p.role)}</p>
      `;
      card.onclick = () => {
        state.selectedId = p.id;
        saveState();
        render();
      };
      grid.appendChild(card);
    });

  if (state.players.length === 0) {
    grid.innerHTML = `<div class="empty-box">No players. Click “Add player” or “Load scenario”.</div>`;
  }
}

function renderSelectedPlayer() {
  const p = selectedPlayer();
  const editor = document.getElementById("playerEditor");
  const empty = document.getElementById("noPlayerBox");

  if (!p) {
    document.getElementById("selectedName").textContent = "No player";
    const teamBadge = document.getElementById("selectedTeam");
    teamBadge.textContent = "None";
    teamBadge.className = "badge";
    editor.style.display = "none";
    empty.style.display = "block";
    return;
  }

  editor.style.display = "block";
  empty.style.display = "none";

  document.getElementById("selectedName").textContent = p.name;
  const teamBadge = document.getElementById("selectedTeam");
  teamBadge.textContent = p.team;
  teamBadge.className = "badge " + teamClass(p.team);

  document.getElementById("editName").value = p.name;
  document.getElementById("editTeam").value = p.team;
  document.getElementById("editRole").value = p.role;
  document.getElementById("editNotes").value = p.notes || "";

  const statusBox = document.getElementById("statusButtons");
  statusBox.innerHTML = "";
  statuses.forEach(s => {
    const btn = document.createElement("button");
    const danger = ["Flagged", "Compromised", "Deported", "Blocked Tonight"].includes(s);
    btn.className = "status-btn" + (p.status.includes(s) ? " on" : "") + (danger ? " danger-status" : "");
    btn.textContent = s;
    btn.onclick = () => {
      snapshot();
      if (p.status.includes(s)) p.status = p.status.filter(x => x !== s);
      else p.status.push(s);
      addPlayerHistory(p, `Status toggled: ${s}.`);
      addLog(`${p.name}: status toggled ${s}.`);
    };
    statusBox.appendChild(btn);
  });

  const list = document.getElementById("dossierList");
  list.innerHTML = "";
  p.dossier.forEach((d, idx) => {
    const row = document.createElement("div");
    row.className = "doc-row";
    row.innerHTML = `
      <div>
        <div class="doc-name">${escapeHtml(d.visibleName)}</div>
        <small>Truth: ${escapeHtml(d.secretTruth)} · Source: ${escapeHtml(d.source || "unknown")} ${d.cleared ? "· Cleared" : ""}</small>
      </div>
      <select data-doc-truth="${idx}">
        ${documentTruths.map(s => `<option ${d.secretTruth === s ? "selected" : ""}>${s}</option>`).join("")}
      </select>
      <button class="icon-btn" data-doc-clear="${idx}">${d.cleared ? "Clear✓" : "Clear"}</button>
      <button class="icon-btn" data-doc-visible="${idx}">${d.visibleToPlayer ? "👁" : "🔒"}</button>
      <button class="icon-btn" data-doc-delete="${idx}">×</button>
    `;
    list.appendChild(row);
  });

  list.querySelectorAll("[data-doc-truth]").forEach(el => {
    el.onchange = e => {
      snapshot();
      const idx = Number(e.target.dataset.docTruth);
      const old = p.dossier[idx].secretTruth;
      p.dossier[idx].secretTruth = e.target.value;
      addPlayerHistory(p, `${p.dossier[idx].visibleName} truth changed from ${old} to ${e.target.value}.`);
      addLog(`${p.name}: ${p.dossier[idx].visibleName} truth changed from ${old} to ${e.target.value}.`);
    };
  });

  list.querySelectorAll("[data-doc-clear]").forEach(el => {
    el.onclick = e => {
      snapshot();
      const idx = Number(e.target.dataset.docClear);
      p.dossier[idx].cleared = !p.dossier[idx].cleared;
      addPlayerHistory(p, `${p.dossier[idx].visibleName} Cleared toggled.`);
      addLog(`${p.name}: ${p.dossier[idx].visibleName} Cleared toggled.`);
    };
  });

  list.querySelectorAll("[data-doc-visible]").forEach(el => {
    el.onclick = e => {
      snapshot();
      const idx = Number(e.target.dataset.docVisible);
      p.dossier[idx].visibleToPlayer = !p.dossier[idx].visibleToPlayer;
      addPlayerHistory(p, `${p.dossier[idx].visibleName} visibility changed.`);
      addLog(`${p.name}: ${p.dossier[idx].visibleName} visibility changed.`);
    };
  });

  list.querySelectorAll("[data-doc-delete]").forEach(el => {
    el.onclick = e => {
      snapshot();
      const idx = Number(e.target.dataset.docDelete);
      const removed = p.dossier.splice(idx, 1)[0];
      addPlayerHistory(p, `Removed document ${removed.visibleName}.`);
      addLog(`${p.name}: removed document ${removed.visibleName}.`);
    };
  });

  renderPlayerHistory(p);
}

function renderPlayerHistory(p) {
  const list = document.getElementById("playerHistoryList");
  list.innerHTML = (p.history || []).map(item => `<div class="history-item">${escapeHtml(item)}</div>`).join("");
}

function renderNight() {
  const day = currentDay();
  document.getElementById("nightDay").textContent = day ? day.id : "-";
  const current = state.nightOrder[state.nightStep];
  document.getElementById("nightRole").textContent = current ? current.role : "No night step";
  document.getElementById("nightPrompt").textContent = current ? current.prompt : "Add night steps to guide the Fixer.";

  const editor = document.getElementById("nightEditor");
  editor.innerHTML = "";
  if (state.nightOrder.length === 0) {
    editor.innerHTML = `<div class="empty-box">No night steps. Add a step or load a scenario.</div>`;
  } else {
    state.nightOrder.forEach((step, idx) => {
      const div = document.createElement("div");
      div.className = "night-step-editor";
      div.innerHTML = `
        <input value="${escapeAttr(step.role)}" data-night-role="${idx}" />
        <input value="${escapeAttr(step.prompt)}" data-night-prompt="${idx}" />
        <button class="icon-btn" data-night-delete="${idx}">×</button>
      `;
      editor.appendChild(div);
    });

    editor.querySelectorAll("[data-night-role]").forEach(el => {
      el.onchange = e => {
        snapshot();
        state.nightOrder[Number(e.target.dataset.nightRole)].role = e.target.value;
        saveState();
        renderNight();
      };
    });

    editor.querySelectorAll("[data-night-prompt]").forEach(el => {
      el.onchange = e => {
        snapshot();
        state.nightOrder[Number(e.target.dataset.nightPrompt)].prompt = e.target.value;
        saveState();
        renderNight();
      };
    });

    editor.querySelectorAll("[data-night-delete]").forEach(el => {
      el.onclick = e => {
        snapshot();
        const idx = Number(e.target.dataset.nightDelete);
        const removed = state.nightOrder.splice(idx, 1)[0];
        state.nightStep = Math.max(0, Math.min(state.nightStep, state.nightOrder.length - 1));
        addLog(`Deleted night step: ${removed.role}.`);
      };
    });
  }

  renderNightBoxVisibility();
  renderNightActionSelectors();
}

function renderNightBoxVisibility() {
  const box = document.getElementById("nightBox");
  const btn = document.getElementById("toggleNightBoxBtn");
  if (!box || !btn) return;
  box.classList.toggle("hidden", !!state.nightBoxHidden);
  btn.textContent = state.nightBoxHidden ? "Show night box" : "Hide night box";
}

function renderNightActionSelectors() {
  const target = document.getElementById("nightTargetSelect");
  const currentValue = target.value;
  target.innerHTML = state.players.map(p => `<option value="${p.id}">${escapeHtml(p.name)} · ${escapeHtml(p.role)}</option>`).join("");
  if (currentValue) target.value = currentValue;
  const p = state.players.find(x => String(x.id) === target.value) || state.players[0];
  const docs = document.getElementById("nightDocumentSelect");
  docs.innerHTML = p ? p.dossier.map((d, idx) => `<option value="${idx}">${escapeHtml(d.visibleName)} · ${escapeHtml(d.secretTruth)}</option>`).join("") : "";
}

function renderDays() {
  const select = document.getElementById("daySelect");
  select.innerHTML = "";
  state.days.forEach(d => {
    const opt = document.createElement("option");
    opt.value = d.id;
    opt.textContent = `Day ${d.id}`;
    select.appendChild(opt);
  });

  if (!currentDay() && state.days.length > 0) state.currentDayId = state.days[0].id;

  if (currentDay()) {
    select.value = String(state.currentDayId);
    document.getElementById("crisisNameInput").value = currentDay().name;
    document.getElementById("crisisTypeInput").value = currentDay().type;
    document.getElementById("crisisTextInput").value = currentDay().text;
    document.getElementById("crisisFixerInput").value = currentDay().fixer;
  } else {
    document.getElementById("crisisNameInput").value = "";
    document.getElementById("crisisTypeInput").value = "";
    document.getElementById("crisisTextInput").value = "";
    document.getElementById("crisisFixerInput").value = "";
  }
}

function renderPublicBoard() {
  const d = currentDay();
  document.getElementById("publicScenario").textContent = state.scenarioName || "Visa Run";
  document.getElementById("publicHeat").textContent = `Heat ${state.heat}`;
  document.getElementById("publicDay").textContent = d ? `Day ${d.id}` : "No day";
  document.getElementById("publicCrisisName").textContent = d ? d.name : "No crisis";
  document.getElementById("publicCrisisText").textContent = d ? d.text : "";
  const box = document.getElementById("publicPlayers");
  box.innerHTML = state.players.map(p => `
    <div class="public-player">
      <h3>${escapeHtml(p.name)}</h3>
      ${p.status.filter(s => ["Active", "Flagged", "Audited", "Cleared", "Compromised", "Protected", "Deported", "Under Review"].includes(s)).map(s => `<span class="badge">${escapeHtml(s)}</span>`).join("")}
    </div>
  `).join("");
}

function renderFinal() {
  const rows = document.getElementById("finalRows");
  rows.innerHTML = "";
  let legal = 0;
  state.players.forEach(p => {
    const exit = likelyExit(p);
    if (exit) legal++;
    const warnings = playerWarnings(p);
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(p.name)}</td>
      <td>${escapeHtml(p.role)}</td>
      <td>${supportCount(p)}</td>
      <td>${escapeHtml(p.status.join(", "))}</td>
      <td><strong>${exit ? "YES" : "NO"}</strong></td>
      <td>${warnings.map(w => `<span class="badge danger">${escapeHtml(w)}</span>`).join("")}</td>
    `;
    rows.appendChild(tr);
  });
  const needed = Number(state.legalExitsNeeded || Math.ceil(state.players.length / 2));
  const victory = document.getElementById("victoryBox");
  victory.innerHTML = `
    <h2>${legal >= needed ? "Nomads can win" : "Scammers win"}</h2>
    <p>${legal} likely legal exits. Current threshold: ${needed} legal exits.</p>
    <p>Then check Independent victory conditions manually.</p>
  `;
}

function renderLog() {
  const list = document.getElementById("logList");
  list.innerHTML = state.log.map(item => `<div class="log-item">${escapeHtml(item)}</div>`).join("");
}

function render() {
  renderScenarioPanel();
  renderHeat();
  renderConfig();
  renderWarnings();
  renderPlayers();
  renderSelectedPlayer();
  renderNight();
  renderDays();
  renderPublicBoard();
  renderFinal();
  renderLog();
  saveState();
}

function bindEvents() {
  document.querySelectorAll(".tab").forEach(tab => {
    tab.onclick = () => {
      document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".tab-content").forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      document.getElementById(`tab-${tab.dataset.tab}`).classList.add("active");
    };
  });

  document.getElementById("openScenarioBtn").onclick = () => {
    document.getElementById("scenarioPanel").classList.toggle("hidden");
  };

  document.getElementById("closeScenarioBtn").onclick = () => {
    document.getElementById("scenarioPanel").classList.add("hidden");
  };

  document.getElementById("newBlankBtn").onclick = () => {
    if (!confirm("Create a blank game? The current game will be replaced.")) return;
    snapshot();
    state = clone(blankState);
    addLog("New blank game created.");
  };

  document.getElementById("undoBtn").onclick = () => {
    if (!state.snapshots || state.snapshots.length === 0) return alert("No undo available.");
    const previous = state.snapshots.shift();
    previous.snapshots = state.snapshots;
    state = previous;
    addLog("Undo applied.");
  };

  document.getElementById("heatMinus").onclick = () => {
    snapshot();
    state.heat = Math.max(0, state.heat - 1);
    addLog(`Heat decreased to ${state.heat}.`);
  };

  document.getElementById("heatPlus").onclick = () => {
    snapshot();
    state.heat = Math.min(Number(state.maxHeat || 6), state.heat + 1);
    addLog(`Heat increased to ${state.heat}.`);
  };

  ["scenarioNameInput", "legalExitsNeededInput", "maxHeatInput", "startingHeatInput"].forEach(id => {
    document.getElementById(id).onchange = e => {
      snapshot();
      if (id === "scenarioNameInput") state.scenarioName = e.target.value;
      if (id === "legalExitsNeededInput") state.legalExitsNeeded = Math.max(1, Number(e.target.value));
      if (id === "maxHeatInput") state.maxHeat = Math.max(1, Number(e.target.value));
      if (id === "startingHeatInput") state.startingHeat = Math.max(0, Number(e.target.value));
      addLog("Scenario config changed.");
    };
  });

  document.getElementById("searchInput").oninput = renderPlayers;

  document.getElementById("addPlayerBtn").onclick = () => {
    snapshot();
    const id = state.players.length ? Math.max(...state.players.map(p => p.id)) + 1 : 1;
    state.players.push(player(id, `Player ${id}`, "Unknown Role", "Nomad", "", [
      doc("Passport", "Valid", true, "manual"),
      doc("Visa Stamp", "Valid", true, "manual"),
      doc("Exit Ticket", "Valid", true, "manual")
    ]));
    if (!state.selectedId) state.selectedId = id;
    state.legalExitsNeeded = Math.max(1, state.legalExitsNeeded || Math.ceil(state.players.length / 2));
    addLog(`Added Player ${id}.`);
  };

  document.getElementById("deletePlayerBtn").onclick = () => {
    const p = selectedPlayer();
    if (!p) return;
    if (!confirm(`Delete ${p.name}?`)) return;
    snapshot();
    state.players = state.players.filter(x => x.id !== p.id);
    state.selectedId = state.players[0]?.id ?? null;
    addLog(`Deleted player ${p.name}.`);
  };

  document.getElementById("editName").onchange = e => {
    const p = selectedPlayer();
    if (!p) return;
    snapshot();
    p.name = e.target.value;
    addPlayerHistory(p, `Renamed to ${e.target.value}.`);
    addLog(`Renamed player to ${e.target.value}.`);
  };

  document.getElementById("editTeam").onchange = e => {
    const p = selectedPlayer();
    if (!p) return;
    snapshot();
    p.team = e.target.value;
    addPlayerHistory(p, `Team changed to ${p.team}.`);
    addLog(`${p.name}: team changed to ${p.team}.`);
  };

  document.getElementById("editRole").onchange = e => {
    const p = selectedPlayer();
    if (!p) return;
    snapshot();
    p.role = e.target.value;
    addPlayerHistory(p, `Role changed to ${p.role}.`);
    addLog(`${p.name}: role changed to ${p.role}.`);
  };

  document.getElementById("editNotes").onchange = e => {
    const p = selectedPlayer();
    if (!p) return;
    snapshot();
    p.notes = e.target.value;
    saveState();
    renderPlayers();
  };

  document.getElementById("addDocBtn").onclick = () => {
    const p = selectedPlayer();
    if (!p) return;
    const visibleName = document.getElementById("newDocName").value.trim();
    const secretTruth = document.getElementById("newDocTruth").value;
    const source = document.getElementById("newDocSource").value.trim() || "manual";
    const notes = document.getElementById("newDocNotes").value.trim();
    if (!visibleName) return;
    snapshot();
    p.dossier.push(doc(visibleName, secretTruth, true, source, notes));
    document.getElementById("newDocName").value = "";
    document.getElementById("newDocSource").value = "";
    document.getElementById("newDocNotes").value = "";
    addPlayerHistory(p, `Added document ${visibleName}; truth ${secretTruth}; source ${source}.`);
    addLog(`${p.name}: added document ${visibleName} (${secretTruth}).`);
  };

  document.getElementById("addPlayerHistoryBtn").onclick = () => {
    const p = selectedPlayer();
    const input = document.getElementById("playerHistoryInput");
    if (!p || !input.value.trim()) return;
    snapshot();
    addPlayerHistory(p, input.value.trim());
    input.value = "";
    addLog(`${p.name}: player history note added.`);
  };

  document.getElementById("nightPrev").onclick = () => {
    state.nightStep = Math.max(0, state.nightStep - 1);
    saveState();
    render();
  };

  document.getElementById("nightNext").onclick = () => {
    state.nightStep = Math.min(Math.max(0, state.nightOrder.length - 1), state.nightStep + 1);
    saveState();
    render();
  };

  document.getElementById("nightDelete").onclick = () => {
    if (!state.nightOrder.length) return;
    snapshot();
    const removed = state.nightOrder.splice(state.nightStep, 1)[0];
    state.nightStep = Math.max(0, Math.min(state.nightStep, state.nightOrder.length - 1));
    addLog(`Deleted night step: ${removed.role}.`);
  };

  document.getElementById("nightReset").onclick = () => {
    state.nightStep = 0;
    addLog("Night assistant reset.");
  };

  document.getElementById("addNightStepBtn").onclick = () => {
    snapshot();
    state.nightOrder.push({ role: "New Night Role", prompt: "Write the Fixer prompt here." });
    state.nightStep = state.nightOrder.length - 1;
    addLog("Added night step.");
  };

  document.getElementById("clearTemporaryBtn").onclick = () => {
    snapshot();
    state.players.forEach(p => p.status = p.status.filter(s => s !== "Blocked Tonight" && s !== "Protected"));
    addLog("Temporary night statuses cleared.");
  };

  document.getElementById("toggleNightBoxBtn").onclick = () => {
    state.nightBoxHidden = !state.nightBoxHidden;
    saveState();
    render();
  };

  document.getElementById("nightTargetSelect").onchange = renderNightActionSelectors;
  document.getElementById("nightActionType").onchange = () => {
    document.getElementById("nightActionResult").innerHTML = "";
  };
  document.getElementById("applyNightActionBtn").onclick = applyNightAction;

  document.getElementById("addDayBtn").onclick = () => {
    snapshot();
    const nextId = state.days.length ? Math.max(...state.days.map(d => d.id)) + 1 : 1;
    state.days.push({ id: nextId, name: `Day ${nextId} Crisis`, type: "Custom Crisis", text: "Write the public crisis text here.", fixer: "Write the Fixer instructions here." });
    state.currentDayId = nextId;
    addLog(`Added Day ${nextId}.`);
  };

  document.getElementById("deleteDayBtn").onclick = () => {
    const d = currentDay();
    if (!d) return;
    if (!confirm(`Delete Day ${d.id}?`)) return;
    snapshot();
    state.days = state.days.filter(x => x.id !== d.id);
    state.currentDayId = state.days[0]?.id ?? null;
    addLog(`Deleted Day ${d.id}.`);
  };

  document.getElementById("daySelect").onchange = e => {
    state.currentDayId = Number(e.target.value);
    state.nightStep = 0;
    addLog(`Moved to Day ${state.currentDayId}.`);
  };

  ["crisisNameInput", "crisisTypeInput", "crisisTextInput", "crisisFixerInput"].forEach(id => {
    document.getElementById(id).onchange = e => {
      const d = currentDay();
      if (!d) return;
      snapshot();
      if (id === "crisisNameInput") d.name = e.target.value;
      if (id === "crisisTypeInput") d.type = e.target.value;
      if (id === "crisisTextInput") d.text = e.target.value;
      if (id === "crisisFixerInput") d.fixer = e.target.value;
      addLog(`Edited Day ${d.id} crisis.`);
    };
  });

  document.getElementById("addLogBtn").onclick = () => {
    const input = document.getElementById("logInput");
    const value = input.value.trim();
    if (!value) return;
    input.value = "";
    addLog(value);
  };

  document.getElementById("clearLogBtn").onclick = () => {
    if (!confirm("Clear the log?")) return;
    snapshot();
    state.log = [];
    saveState();
    render();
  };

  document.getElementById("exportBtn").onclick = exportJSON;
  document.getElementById("summaryBtn").onclick = exportSummary;
  document.getElementById("downloadScenarioTemplateBtn").onclick = downloadScenarioTemplate;

  document.getElementById("importInput").onchange = e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        snapshot();
        state = migrateState(JSON.parse(reader.result));
        addLog("Imported save JSON.");
      } catch {
        alert("Invalid JSON file.");
      }
    };
    reader.readAsText(file);
  };

  document.getElementById("scenarioImportInput").onchange = e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const scenario = normalizeScenario(JSON.parse(reader.result));
        if (!confirm(`Load custom scenario "${scenario.name}"? The current game will be replaced.`)) return;
        snapshot();
        state = scenarioToState(scenario);
        document.getElementById("scenarioPanel").classList.add("hidden");
        addLog(`Custom scenario loaded: ${scenario.name}.`);
      } catch (err) {
        alert("Invalid scenario JSON. Check README for the expected format.");
      }
    };
    reader.readAsText(file);
  };

  document.getElementById("resetBtn").onclick = () => {
    if (!confirm("Clear all local saves and return to a blank game?")) return;
    state = clone(blankState);
    localStorage.removeItem(STORAGE_KEY);
    render();
  };
}

function normalizeScenario(raw) {
  const scenario = clone(raw);
  if (!scenario.name) scenario.name = "Custom Imported Scenario";
  if (!Array.isArray(scenario.players)) scenario.players = [];
  if (!Array.isArray(scenario.days)) scenario.days = [];
  if (!Array.isArray(scenario.nightOrder)) scenario.nightOrder = [];

  scenario.players = scenario.players.map((p, idx) => ({
    id: p.id ?? idx + 1,
    name: p.name ?? `Player ${idx + 1}`,
    role: p.role ?? "Unknown Role",
    team: p.team ?? "Unknown",
    status: p.status ?? ["Active"],
    notes: p.notes ?? "",
    history: p.history ?? [],
    dossier: (p.dossier ?? []).map(d => ({
      visibleName: d.visibleName ?? d.name ?? "Document",
      secretTruth: d.secretTruth ?? d.state ?? "Valid",
      visibleToPlayer: d.visibleToPlayer ?? d.visible ?? true,
      source: d.source ?? "scenario",
      notes: d.notes ?? "",
      cleared: d.cleared ?? false
    }))
  }));

  scenario.days = scenario.days.map((d, idx) => ({
    id: d.id ?? idx + 1,
    name: d.name ?? `Day ${idx + 1} Crisis`,
    type: d.type ?? "Custom Crisis",
    text: d.text ?? "",
    fixer: d.fixer ?? ""
  }));

  return scenario;
}

function applyNightAction() {
  const action = document.getElementById("nightActionType").value;
  const targetId = Number(document.getElementById("nightTargetSelect").value);
  const p = state.players.find(x => x.id === targetId);
  if (!p) return;
  snapshot();

  if (action === "block") {
    if (!p.status.includes("Blocked Tonight")) p.status.push("Blocked Tonight");
    addPlayerHistory(p, "Blocked tonight.");
    addLog(`${p.name} blocked tonight.`);
    setNightResult(`${p.name} receives Blocked Tonight.`);
  }

  if (action === "protect") {
    if (!p.status.includes("Protected")) p.status.push("Protected");
    addPlayerHistory(p, "Dossier protected tonight.");
    addLog(`${p.name} protected tonight.`);
    setNightResult(`${p.name}'s Dossier is Protected.`);
  }

  if (action === "addDocument") {
    const visibleName = document.getElementById("nightNewDocName").value.trim() || "New Document";
    const secretTruth = document.getElementById("nightDocumentTruth").value;
    const source = document.getElementById("nightNewDocSource").value.trim() || `Night ${currentDay()?.id ?? ""}`;
    p.dossier.push(doc(visibleName, secretTruth, true, source));
    addPlayerHistory(p, `Night action: received ${visibleName}; truth ${secretTruth}; source ${source}.`);
    addLog(`${p.name}: night action added ${visibleName} (${secretTruth}).`);
    setNightResult(`${visibleName} added to ${p.name}. Player sees the document name; Fixer truth is ${secretTruth}.`);
  }

  if (action === "checkDocument") {
    const idx = Number(document.getElementById("nightDocumentSelect").value);
    const d = p.dossier[idx];
    if (!d) return;
    const answer = getCheckAnswer(d);
    addLog(`Checked ${p.name}'s ${d.visibleName}: ${answer}.`);
    setNightResult(`Fixer answer for ${p.name}'s ${d.visibleName}: ${answer}. Secret truth is ${d.secretTruth}.`);
  }

  if (action === "repairDocument") {
    const idx = Number(document.getElementById("nightDocumentSelect").value);
    const d = p.dossier[idx];
    if (!d) return;
    const old = d.secretTruth;
    d.secretTruth = "Valid";
    d.cleared = true;
    addPlayerHistory(p, `Repaired/Cleared ${d.visibleName}. Truth changed from ${old} to Valid.`);
    addLog(`${p.name}: ${d.visibleName} repaired and Cleared.`);
    setNightResult(`${p.name}'s ${d.visibleName} is now Valid and Cleared.`);
  }

  render();
}

function getCheckAnswer(d) {
  if (d.secretTruth === "Valid") return "Valid";
  if (["Fake", "Expired", "Missing", "Hidden Complication"].includes(d.secretTruth)) return "Invalid";
  if (d.secretTruth === "Suspicious") return "Suspicious";
  return "Unknown";
}

function setNightResult(msg) {
  document.getElementById("nightActionResult").innerHTML = escapeHtml(msg);
}

function exportJSON() {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  downloadBlob(blob, "visa-run-fixer-console-v0-5-save.json");
}

function exportSummary() {
  let legal = 0;
  const lines = [];
  lines.push(`# Visa Run Game Summary`);
  lines.push("");
  lines.push(`Scenario: ${state.scenarioName}`);
  lines.push(`Heat final: ${state.heat}`);
  lines.push(`Legal exits needed: ${state.legalExitsNeeded}`);
  lines.push("");
  lines.push(`## Final Border Check`);
  state.players.forEach(p => {
    const exit = likelyExit(p);
    if (exit) legal++;
    lines.push(`- ${p.name}: ${exit ? "LIKELY EXIT" : "NO EXIT"} · ${p.role} · ${p.team} · Status: ${p.status.join(", ")}`);
  });
  lines.push("");
  lines.push(`Result estimate: ${legal} legal exits. ${legal >= state.legalExitsNeeded ? "Nomads can win." : "Scammers win."}`);
  lines.push("");
  lines.push(`## Player Details`);
  state.players.forEach(p => {
    lines.push(`### ${p.name}`);
    lines.push(`Role: ${p.role}`);
    lines.push(`Team: ${p.team}`);
    lines.push(`Status: ${p.status.join(", ")}`);
    lines.push(`Dossier:`);
    p.dossier.forEach(d => lines.push(`- Visible: ${d.visibleName} | Truth: ${d.secretTruth} | Source: ${d.source || ""} | Cleared: ${d.cleared ? "yes" : "no"}`));
    if (p.history.length) {
      lines.push(`History:`);
      p.history.forEach(h => lines.push(`- ${h}`));
    }
    lines.push("");
  });
  lines.push(`## Global Log`);
  state.log.forEach(l => lines.push(`- ${l}`));
  const blob = new Blob([lines.join("\n")], { type: "text/markdown" });
  downloadBlob(blob, "visa-run-game-summary.md");
}

function downloadScenarioTemplate() {
  const template = {
    id: "my-custom-scenario",
    name: "My Custom Scenario",
    difficulty: "Custom",
    description: "Short description of the scenario.",
    legalExitsNeeded: 5,
    maxHeat: 6,
    startingHeat: 0,
    players: [
      {
        id: 1,
        name: "Player 1",
        role: "Embassy Contact",
        team: "Nomad",
        status: ["Active"],
        notes: "Role notes for the Fixer.",
        history: [],
        dossier: [
          { visibleName: "Passport", secretTruth: "Valid", visibleToPlayer: true, source: "setup", notes: "", cleared: false },
          { visibleName: "Visa Stamp", secretTruth: "Suspicious", visibleToPlayer: true, source: "setup", notes: "", cleared: false },
          { visibleName: "Exit Ticket", secretTruth: "Valid", visibleToPlayer: true, source: "setup", notes: "", cleared: false }
        ]
      }
    ],
    days: [
      { id: 1, name: "Random Passport Check", type: "Light Crisis", text: "Public text read to players.", fixer: "Secret Fixer instructions." }
    ],
    nightOrder: [
      { role: "Embassy Contact", prompt: "Choose one player and one document type." }
    ]
  };
  const blob = new Blob([JSON.stringify(template, null, 2)], { type: "application/json" });
  downloadBlob(blob, "visa-run-custom-scenario-template.json");
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, m => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[m]));
}

function escapeAttr(str) {
  return escapeHtml(str).replace(/`/g, "&#096;");
}

bindEvents();
render();
